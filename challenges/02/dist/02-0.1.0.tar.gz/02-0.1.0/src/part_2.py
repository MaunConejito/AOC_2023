def process(input: str):
    return input